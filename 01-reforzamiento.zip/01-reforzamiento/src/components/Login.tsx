import { useEffect, useReducer } from "react";


interface AuthState {
    validando: boolean,
    token: string | null,
    username: string,
    nombre: string
}

//definimos el estado inicial
const initialState: AuthState = {
    validando: true,
    token: null,
    username: "",
    nombre: ""
}
type LoginPayload = { 
    username: string,
    nombre: string
}

//definimos las acciones que puede realizar el reducer,
//para mas acciones ponemos la | seguido de la accion, el payload es informacion addicional
type AuthAction = 
    | { type: 'logout' }
    | { type: 'login', payload: LoginPayload }

//retorna un estado igual a la initialState , action modifica el state
const authReducer = ( state:AuthState, action:AuthAction ):AuthState =>{
    //cuerpo del reducer
    switch (action.type) {
        case 'logout':
            return{
                validando:false,
                token:null,
                nombre:"",
                username:""
            }
        case 'login':
            const { nombre, username} = action.payload;
            return{
                validando:false,
                token:'ABC123',
                nombre:nombre,
                username:username
            }
        default:
            return state;
    }
}

export const Login = () => {

    //const [state, dispatch] = useReducer(authReducer, initialState); coges todo el objeto de initialState
    const [{ validando, token, nombre }, dispatch] = useReducer(authReducer, initialState); //coges solo el validando de initialState

    //useEffect salta la primera vez que se renderiza el componente, 
    //si queremos que salte cada vez que cambie una estado en el arreglo lo añadimos [estado]
    useEffect(() => {
        setTimeout(() => {
            dispatch({ type: 'logout'})
        }, 1500);
    }, [])
    
    const login = () => {
        dispatch({ 
            type:"login" , 
            payload:{
                nombre:"Isma",
                username:"ispipa"
            }
        })
        console.log(token)
    }
    const logout = () => {
        dispatch({ 
            type:"logout"
        })
        console.log((token))
    }

    if(validando){
        return(
            <>
                <h3>Login</h3>
                <div className="alert alert-info">
                    Validando...
                </div>
            </>
        )
    }

  return (
    <>
        <h3>Login</h3>
        {
            ( token ) ? <div className="alert alert-success">Autenticado como: { nombre }</div> 
            : <div className="alert alert-danger">No autenticado</div>
        }
        {
            ( token ) ?  <button className="btn btn-danger" onClick={ logout }>Logout</button>
            : <button className="btn btn-primary" onClick={ login }>Login</button>
        }
    </>
  )
}
