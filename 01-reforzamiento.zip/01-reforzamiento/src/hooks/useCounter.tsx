import { useState } from "react";

export const useCounter = ( inicial:number = 10) => {

    const [valor, setvalor] = useState<number>(inicial);

    const setNum = (numero:number) =>{
      setvalor(valor + numero);
    }

    return{
        valor,
        setNum
    }
}
