import { useState } from 'react';
                        //tipo generico, es decir T es cualquier tipo
export const useForm = <T extends Object>(  formulario:T ) => {

    const [state, setState] = useState(formulario);
                                    //    heyof, una llave q exista en T
    const onChange = ( value:string , campo: keyof T ) => {
        setState({
            ...state,
            //computa un nuevo atributo y se le asigna un valor
            [campo]:value
        });
    }

    return{
        ...state,
        formulario: state,
        onChange
    }
}
