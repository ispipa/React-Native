import { useEffect, useRef, useState } from "react";
import { reqResApi } from "../api/reqRes";
import { RepResListado, User } from "../interfaces/reqRes";

export const useUsuarios = () => {

    const [usuarios, setUsuarios] = useState<User[]>([]);

    const pageRef = useRef(1)
  
    useEffect(() => {
      return () => {
        paginaSiguiente();
        paginaAnterior();
      }
    }, [])
  
    const getUsers = async () => {
       //llamada a la api
        const response = await reqResApi.get<RepResListado>('/users', {
          params:{
                //es la referencia al valor del useRef
              page:pageRef.current
          }
        });
        if(response.data.data.length > 0){
          setUsuarios(response.data.data);
        }
        else{
          pageRef.current --;
          alert("No hay registros");
        }
    }

    const paginaSiguiente = () => {
        pageRef.current ++;
        getUsers();
    }

    const paginaAnterior = () => {
        if(pageRef.current > 1){
            pageRef.current --;
            getUsers();
        }
    }

    return{
        usuarios,
        paginaSiguiente,
        paginaAnterior
    }
}
