//interfaces solo sirven para poner reglas de validación a los objetos
interface Persona{
    nombre: string,
    edad: number,
    direccion: Direccion,  

}
interface Direccion{
    pais: string,
    numCasa: number
}

export const ObjetosLiterales = () => {

    const persona: Persona = {
        nombre: "Fernando",
        edad: 35,
        direccion:{
            pais:"Canada",
            numCasa:35
        }
    }

  return (
    <>
        <h3>Objetos Literales</h3>
        {/* JSON.stringify( persona ) */}
        <code>
            <pre>
                { JSON.stringify( persona, null, 2 ) }
            </pre>
        </code>

    </>
  )
}
