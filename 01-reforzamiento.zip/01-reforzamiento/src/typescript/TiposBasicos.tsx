
export const TiposBasicos = () => {

  //tipado string error al asignar un numero a una variable de tipo string
  /*let nombre = "Fernando";
  nombre = 123;*/

  //tipado para asignar diferentes tipos de datos a una variable
  /*let nombre: string | number = "Fernando";
  nombre = 123;*/

  const nombre: string  = "Fernando";
  const edad: number = 35;
  const estaActivo: boolean = false;

  const poderes: string[] = [];//"Velocidad", "Volar", "Respirar en el agua", "Super Fuerza"

  poderes.push("Velocidad");
  poderes.push("Volar");
  poderes.push("Respirar en el agua");
  poderes.push("Super Fuerza");  


  return (
    <>
        <h3>Tipos  básicos</h3>
        { nombre } , { edad } , { (estaActivo) ? 'Activo' : 'Inactivo' }
        <br/>
        { poderes.join(", ") }
    </>
  )
}
